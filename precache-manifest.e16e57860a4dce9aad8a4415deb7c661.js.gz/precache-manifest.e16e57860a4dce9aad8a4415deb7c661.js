self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0a54cdb4da37c7b8670e39644701e859",
    "url": "/index.html"
  },
  {
    "revision": "937d32e7557d2bbbcff5",
    "url": "/static/css/2.068e8dc1.chunk.css"
  },
  {
    "revision": "e3f77a0fc7515a620c58",
    "url": "/static/css/main.0fdf0e84.chunk.css"
  },
  {
    "revision": "937d32e7557d2bbbcff5",
    "url": "/static/js/2.d3e1bb2e.chunk.js"
  },
  {
    "revision": "e3f77a0fc7515a620c58",
    "url": "/static/js/main.5952e7d2.chunk.js"
  },
  {
    "revision": "a9bc34c64233edaba836",
    "url": "/static/js/runtime-main.37dd6726.js"
  },
  {
    "revision": "86f95a8e5c5532acae8666e4878105b5",
    "url": "/static/media/award.86f95a8e.png"
  },
  {
    "revision": "66afdc64e04580694d07af77984fbc2f",
    "url": "/static/media/depthAll.66afdc64.svg"
  },
  {
    "revision": "efcbc04e67ec7eccf3965ed2636fd4cd",
    "url": "/static/media/depthBuy.efcbc04e.svg"
  },
  {
    "revision": "58406931cb536ebc2e5c57db7e821a12",
    "url": "/static/media/depthSell.58406931.svg"
  },
  {
    "revision": "a1d793c00fe64ca782edff02e2c1290e",
    "url": "/static/media/wedexLogo.a1d793c0.svg"
  },
  {
    "revision": "d319b12fb327de70a1c7877cc25a2e35",
    "url": "/static/media/wedexLogoVertical.d319b12f.png"
  }
]);