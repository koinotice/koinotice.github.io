self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "346feba1c0e5ece8c32dfc8fbed92b38",
    "url": "/index.html"
  },
  {
    "revision": "1548953a87768e760f6b",
    "url": "/static/css/2.2579242d.chunk.css"
  },
  {
    "revision": "c2df373329d80c6ec12b",
    "url": "/static/css/main.2930bad1.chunk.css"
  },
  {
    "revision": "1548953a87768e760f6b",
    "url": "/static/js/2.43594415.chunk.js"
  },
  {
    "revision": "c2df373329d80c6ec12b",
    "url": "/static/js/main.52e8287d.chunk.js"
  },
  {
    "revision": "a9bc34c64233edaba836",
    "url": "/static/js/runtime-main.37dd6726.js"
  },
  {
    "revision": "86f95a8e5c5532acae8666e4878105b5",
    "url": "/static/media/award.86f95a8e.png"
  },
  {
    "revision": "e7a2fb3ee01585523b0b21ecad0c9fb2",
    "url": "/static/media/chartSetting.e7a2fb3e.svg"
  },
  {
    "revision": "41ca9c0b3d6b8a94d97efa1a75e04cfb",
    "url": "/static/media/chartTechnic.41ca9c0b.svg"
  },
  {
    "revision": "66afdc64e04580694d07af77984fbc2f",
    "url": "/static/media/depthAll.66afdc64.svg"
  },
  {
    "revision": "efcbc04e67ec7eccf3965ed2636fd4cd",
    "url": "/static/media/depthBuy.efcbc04e.svg"
  },
  {
    "revision": "58406931cb536ebc2e5c57db7e821a12",
    "url": "/static/media/depthSell.58406931.svg"
  },
  {
    "revision": "5f4ffc050edf81d162af737e2af74f27",
    "url": "/static/media/fullscreen.5f4ffc05.svg"
  },
  {
    "revision": "6266a393d133b7e2592118ef3e4e99ac",
    "url": "/static/media/wedexLogo.6266a393.svg"
  },
  {
    "revision": "d319b12fb327de70a1c7877cc25a2e35",
    "url": "/static/media/wedexLogoVertical.d319b12f.png"
  }
]);